// Pin pada ESP32
const int pinSensor = 34; // GPIO 34 (Input Analog)
const int ledMerah  = 25; // GPIO 25
const int ledHijau  = 26; // GPIO 26
const int buzzer    = 27; // GPIO 27

// Rentang analog ESP32 adalah 0 - 4095
// Angka > 2500 kita anggap tanah KERING
int batasKering = 2500;

void setup() {
  Serial.begin(115200); // ESP32 standar kecepatannya 115200
  pinMode(ledMerah, OUTPUT);
  pinMode(ledHijau, OUTPUT);
  pinMode(buzzer, OUTPUT);
}

void loop() {
  int nilaiTanah = analogRead(pinSensor);

  // Ubah angka 0-4095 jadi persentase kelembapan (0% - 100%) biar enak dibaca
  int persenLembap = map(nilaiTanah, 4095, 0, 0, 100);

  Serial.print("Nilai Sensor: ");
  Serial.print(nilaiTanah);
  Serial.print(" | Kelembapan: ");
  Serial.print(persenLembap);
  Serial.println("%");

  if (nilaiTanah > batasKering) {
    // Kondisi KERING (Minta disiram)
    digitalWrite(ledMerah, HIGH);
    digitalWrite(ledHijau, LOW);

    tone(buzzer, 1000);
    delay(250);
    noTone(buzzer);
    delay(500);
  } else {
    // Kondisi BASAH / AMAN
    digitalWrite(ledMerah, LOW);
    digitalWrite(ledHijau, HIGH);

    noTone(buzzer);
    delay(300);
  }
}